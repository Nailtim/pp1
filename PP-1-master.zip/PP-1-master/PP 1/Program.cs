﻿Console.Write("Введите первое число: ");
int number1 = Convert.ToInt32(Console.ReadLine());

Console.Write("Введите второе число: ");
int number2 = Convert.ToInt32(Console.ReadLine());

Console.WriteLine($"Сумма: {number1 + number2}");

Console.WriteLine($"Разность: {number1 - number2}");

Console.WriteLine($"Произведение: {number1 * number2}");

Console.WriteLine($"Деление без остатка: {number1 / number2}");